(self["webpackChunktest_il_webapp"] = self["webpackChunktest_il_webapp"] || []).push([["common"],{

/***/ 6887:
/*!******************************************************!*\
  !*** ./src/app/core/services/ingredienti.service.ts ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IngredientiService": function() { return /* binding */ IngredientiService; }
/* harmony export */ });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 5257);
/* harmony import */ var src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/rest-utils */ 2393);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 1841);




class IngredientiService {
    constructor(http) {
        this.http = http;
    }
    /**
     * Recupera lista ingredienti
     *
     * @returns lista ingredienti
     */
    getAllIngredienti() {
        return new Promise((resolve, reject) => {
            this.http.get(src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.CRUD_INGREDIENTI, { observe: 'response' })
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1))
                .subscribe((resp) => {
                resolve(resp.body.response);
            }, (err) => {
                reject(err);
            });
        });
    }
    /**
     * Recupera ingrediente specifico
     *
     * @param id
     * @returns ingrediente
     */
    getIngredienteById(id) {
        return new Promise((resolve, reject) => {
            this.http.get(`${src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.CRUD_INGREDIENTI}/${id}`, { observe: 'response' })
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1))
                .subscribe((resp) => {
                resolve(resp.body.response);
            }, (err) => {
                reject(err);
            });
        });
    }
    /**
     * Richiede creazione ingrediente
     *
     * @param ingrediente
     * @returns ingrediente creato
     */
    addIngrediente(ingrediente) {
        return new Promise((resolve, reject) => {
            this.http.post(src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.CRUD_INGREDIENTI, ingrediente, { observe: 'response' })
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1))
                .subscribe((resp) => {
                resolve(resp.body.response);
            }, (err) => {
                reject(err);
            });
        });
    }
    /**
     * Richiede aggiornamento ingrediente
     *
     * @param id
     * @param ingrediente
     * @returns ingrediente aggiornato
     */
    updateIngrediente(id, ingrediente) {
        return new Promise((resolve, reject) => {
            this.http.put(`${src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.CRUD_INGREDIENTI}/${id}`, ingrediente, { observe: 'response' })
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1))
                .subscribe((resp) => {
                resolve(resp.body.response);
            }, (err) => {
                reject(err);
            });
        });
    }
    /**
     * Richiede eliminazione ingrediente
     *
     * @param id
     * @
     */
    deleteIngrediente(id) {
        return new Promise((resolve, reject) => {
            this.http.delete(`${src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.CRUD_INGREDIENTI}/${id}`, { observe: 'response' })
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1))
                .subscribe((resp) => {
                resolve(resp.body.response);
            }, (err) => {
                reject(err);
            });
        });
    }
}
IngredientiService.ɵfac = function IngredientiService_Factory(t) { return new (t || IngredientiService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient)); };
IngredientiService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: IngredientiService, factory: IngredientiService.ɵfac, providedIn: "root" });


/***/ }),

/***/ 3618:
/*!**************************************************!*\
  !*** ./src/app/core/services/vetrina.service.ts ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VetrinaService": function() { return /* binding */ VetrinaService; }
/* harmony export */ });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 5257);
/* harmony import */ var src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/rest-utils */ 2393);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 1841);




class VetrinaService {
    constructor(http) {
        this.http = http;
    }
    /**
     * Richiede dolci da mostrare in vetrina
     *
     * @returns dolci vetrina
     */
    getAllDolciVetrina() {
        return new Promise((resolve, reject) => {
            this.http.get(src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.VETRINA, { observe: 'response' })
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1))
                .subscribe((resp) => {
                resolve(resp.body.response);
            }, (err) => {
                reject(err);
            });
        });
    }
    /**
     * Richiede l'aggiunta di un dolce in vetrina con i relativi attributi
     *
     * @param idDolce dolce da aggiungere in vetrina
     * @param formAddVetrina quantita e prezzo base
     * @returns dolce vetrina aggiunto
     */
    addDolceToVetrina(idDolce, formAddVetrina) {
        return new Promise((resolve, reject) => {
            this.http.post(`${src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.VETRINA_DOLCE}/${idDolce}`, formAddVetrina, { observe: 'response' })
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1))
                .subscribe((resp) => {
                resolve(resp.body.response);
            }, (err) => {
                reject(err);
            });
        });
    }
    /**
     * Richiede la rimozione di un dolce dalla vetrina
     *
     * @param idDolce
     * @returns
     */
    deleteDolceFromVetrina(idDolce) {
        return new Promise((resolve, reject) => {
            this.http.delete(`${src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.VETRINA_DOLCE}/${idDolce}`, { observe: 'response' })
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1))
                .subscribe((resp) => {
                resolve(resp.body.response);
            }, (err) => {
                reject(err);
            });
        });
    }
}
VetrinaService.ɵfac = function VetrinaService_Factory(t) { return new (t || VetrinaService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient)); };
VetrinaService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: VetrinaService, factory: VetrinaService.ɵfac, providedIn: "root" });


/***/ })

}]);
//# sourceMappingURL=common-es2015.js.map