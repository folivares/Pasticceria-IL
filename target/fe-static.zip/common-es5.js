(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (self["webpackChunktest_il_webapp"] = self["webpackChunktest_il_webapp"] || []).push([["common"], {
    /***/
    6887: function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "IngredientiService": function IngredientiService() {
          return (
            /* binding */
            _IngredientiService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! rxjs/operators */
      5257);
      /* harmony import */


      var src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! src/app/shared/rest-utils */
      2393);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      7716);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common/http */
      1841);

      var _IngredientiService = /*#__PURE__*/function () {
        function _IngredientiService(http) {
          _classCallCheck(this, _IngredientiService);

          this.http = http;
        }
        /**
         * Recupera lista ingredienti
         *
         * @returns lista ingredienti
         */


        _createClass(_IngredientiService, [{
          key: "getAllIngredienti",
          value: function getAllIngredienti() {
            var _this = this;

            return new Promise(function (resolve, reject) {
              _this.http.get(src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.CRUD_INGREDIENTI, {
                observe: 'response'
              }).pipe((0, rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1)).subscribe(function (resp) {
                resolve(resp.body.response);
              }, function (err) {
                reject(err);
              });
            });
          }
          /**
           * Recupera ingrediente specifico
           *
           * @param id
           * @returns ingrediente
           */

        }, {
          key: "getIngredienteById",
          value: function getIngredienteById(id) {
            var _this2 = this;

            return new Promise(function (resolve, reject) {
              _this2.http.get("".concat(src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.CRUD_INGREDIENTI, "/").concat(id), {
                observe: 'response'
              }).pipe((0, rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1)).subscribe(function (resp) {
                resolve(resp.body.response);
              }, function (err) {
                reject(err);
              });
            });
          }
          /**
           * Richiede creazione ingrediente
           *
           * @param ingrediente
           * @returns ingrediente creato
           */

        }, {
          key: "addIngrediente",
          value: function addIngrediente(ingrediente) {
            var _this3 = this;

            return new Promise(function (resolve, reject) {
              _this3.http.post(src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.CRUD_INGREDIENTI, ingrediente, {
                observe: 'response'
              }).pipe((0, rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1)).subscribe(function (resp) {
                resolve(resp.body.response);
              }, function (err) {
                reject(err);
              });
            });
          }
          /**
           * Richiede aggiornamento ingrediente
           *
           * @param id
           * @param ingrediente
           * @returns ingrediente aggiornato
           */

        }, {
          key: "updateIngrediente",
          value: function updateIngrediente(id, ingrediente) {
            var _this4 = this;

            return new Promise(function (resolve, reject) {
              _this4.http.put("".concat(src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.CRUD_INGREDIENTI, "/").concat(id), ingrediente, {
                observe: 'response'
              }).pipe((0, rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1)).subscribe(function (resp) {
                resolve(resp.body.response);
              }, function (err) {
                reject(err);
              });
            });
          }
          /**
           * Richiede eliminazione ingrediente
           *
           * @param id
           * @
           */

        }, {
          key: "deleteIngrediente",
          value: function deleteIngrediente(id) {
            var _this5 = this;

            return new Promise(function (resolve, reject) {
              _this5.http["delete"]("".concat(src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.CRUD_INGREDIENTI, "/").concat(id), {
                observe: 'response'
              }).pipe((0, rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1)).subscribe(function (resp) {
                resolve(resp.body.response);
              }, function (err) {
                reject(err);
              });
            });
          }
        }]);

        return _IngredientiService;
      }();

      _IngredientiService.ɵfac = function IngredientiService_Factory(t) {
        return new (t || _IngredientiService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient));
      };

      _IngredientiService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
        token: _IngredientiService,
        factory: _IngredientiService.ɵfac,
        providedIn: "root"
      });
      /***/
    },

    /***/
    3618: function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "VetrinaService": function VetrinaService() {
          return (
            /* binding */
            _VetrinaService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! rxjs/operators */
      5257);
      /* harmony import */


      var src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! src/app/shared/rest-utils */
      2393);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      7716);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common/http */
      1841);

      var _VetrinaService = /*#__PURE__*/function () {
        function _VetrinaService(http) {
          _classCallCheck(this, _VetrinaService);

          this.http = http;
        }
        /**
         * Richiede dolci da mostrare in vetrina
         *
         * @returns dolci vetrina
         */


        _createClass(_VetrinaService, [{
          key: "getAllDolciVetrina",
          value: function getAllDolciVetrina() {
            var _this6 = this;

            return new Promise(function (resolve, reject) {
              _this6.http.get(src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.VETRINA, {
                observe: 'response'
              }).pipe((0, rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1)).subscribe(function (resp) {
                resolve(resp.body.response);
              }, function (err) {
                reject(err);
              });
            });
          }
          /**
           * Richiede l'aggiunta di un dolce in vetrina con i relativi attributi
           *
           * @param idDolce dolce da aggiungere in vetrina
           * @param formAddVetrina quantita e prezzo base
           * @returns dolce vetrina aggiunto
           */

        }, {
          key: "addDolceToVetrina",
          value: function addDolceToVetrina(idDolce, formAddVetrina) {
            var _this7 = this;

            return new Promise(function (resolve, reject) {
              _this7.http.post("".concat(src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.VETRINA_DOLCE, "/").concat(idDolce), formAddVetrina, {
                observe: 'response'
              }).pipe((0, rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1)).subscribe(function (resp) {
                resolve(resp.body.response);
              }, function (err) {
                reject(err);
              });
            });
          }
          /**
           * Richiede la rimozione di un dolce dalla vetrina
           *
           * @param idDolce
           * @returns
           */

        }, {
          key: "deleteDolceFromVetrina",
          value: function deleteDolceFromVetrina(idDolce) {
            var _this8 = this;

            return new Promise(function (resolve, reject) {
              _this8.http["delete"]("".concat(src_app_shared_rest_utils__WEBPACK_IMPORTED_MODULE_0__.API_URL.VETRINA_DOLCE, "/").concat(idDolce), {
                observe: 'response'
              }).pipe((0, rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.take)(1)).subscribe(function (resp) {
                resolve(resp.body.response);
              }, function (err) {
                reject(err);
              });
            });
          }
        }]);

        return _VetrinaService;
      }();

      _VetrinaService.ɵfac = function VetrinaService_Factory(t) {
        return new (t || _VetrinaService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient));
      };

      _VetrinaService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
        token: _VetrinaService,
        factory: _VetrinaService.ɵfac,
        providedIn: "root"
      });
      /***/
    }
  }]);
})();
//# sourceMappingURL=common-es5.js.map